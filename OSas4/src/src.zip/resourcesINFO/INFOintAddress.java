package resourcesINFO;


public class INFOintAddress extends INFO {

}
