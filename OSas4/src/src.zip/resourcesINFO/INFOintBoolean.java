package resourcesINFO;


public class INFOintBoolean extends INFO {

}
