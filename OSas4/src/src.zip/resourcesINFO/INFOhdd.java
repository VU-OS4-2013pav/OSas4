package resourcesINFO;


public class INFOhdd extends INFO {

}
