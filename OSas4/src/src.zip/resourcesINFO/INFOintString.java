package resourcesINFO;


public class INFOintString extends INFO {

}
