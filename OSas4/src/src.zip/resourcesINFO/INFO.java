package resourcesINFO;

public class INFO {

}
