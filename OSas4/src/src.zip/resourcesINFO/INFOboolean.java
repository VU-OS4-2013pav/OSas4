package resourcesINFO;


public class INFOboolean extends INFO {

}
