package resourcesINFO;

public class INFOchanDev {

}
