package resourcesINFO;

public class INFObooleanList {

}
