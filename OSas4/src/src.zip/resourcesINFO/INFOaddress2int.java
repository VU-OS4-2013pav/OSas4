package resourcesINFO;

public class INFOaddress2int {

}
