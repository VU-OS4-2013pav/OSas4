package resourcesINFO;

public class INFOstring {

}
