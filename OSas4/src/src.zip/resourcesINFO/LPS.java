package resourcesINFO;

import processes.ProcessBase;

public class LPS {
	ProcessBase[] laukiantysProc;
	int kiekReikia;
	

}
