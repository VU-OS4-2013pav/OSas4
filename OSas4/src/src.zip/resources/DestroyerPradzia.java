package resources;

public class DestroyerPradzia extends ResourceBase {

}
