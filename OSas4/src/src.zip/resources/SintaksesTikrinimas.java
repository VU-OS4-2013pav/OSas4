package resources;

public class SintaksesTikrinimas extends ResourceBase {

}
