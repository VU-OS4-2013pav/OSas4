package resources;

public class ResourceBase {
	int r;


}
