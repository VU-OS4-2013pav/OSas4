package resources;

public class VMnoriIvedimo extends ResourceBase {

}
