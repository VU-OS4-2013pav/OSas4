package resources;

public class SintaksePatikrinta extends ResourceBase {

}
