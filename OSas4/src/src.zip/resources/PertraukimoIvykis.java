package resources;

public class PertraukimoIvykis extends ResourceBase {

}
