package resources;


public class MOSpabaiga extends ResourceBase {

}
