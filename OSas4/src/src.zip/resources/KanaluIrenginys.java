package resources;

public class KanaluIrenginys extends ResourceBase {

}
