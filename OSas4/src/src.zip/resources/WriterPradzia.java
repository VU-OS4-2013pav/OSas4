package resources;

public class WriterPradzia extends ResourceBase {

}
