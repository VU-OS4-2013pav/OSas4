package resources;

public class MainGovernorPazadinimas extends ResourceBase {

}
