package resources;

public class VartotojoAtmintis extends ResourceBase {

}
