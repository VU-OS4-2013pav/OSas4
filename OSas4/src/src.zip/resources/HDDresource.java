package resources;

public class HDDresource extends ResourceBase {

}
