package resources;

public class LoaderPabaiga extends ResourceBase {

}
