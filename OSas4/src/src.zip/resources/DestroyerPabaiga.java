package resources;

public class DestroyerPabaiga extends ResourceBase {

}
