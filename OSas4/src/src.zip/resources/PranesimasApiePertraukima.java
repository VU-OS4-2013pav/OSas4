package resources;

public class PranesimasApiePertraukima extends ResourceBase {

}
