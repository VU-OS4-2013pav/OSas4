package resources;

public class LoaderPradzia extends ResourceBase {

}
