package resources;

public class InputStreamPabaiga extends ResourceBase {

}
