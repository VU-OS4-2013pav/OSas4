package resources;

public class SwapperPradzia extends ResourceBase {

}
