package resources;

public class KlaviaturosPertraukimas extends ResourceBase {

}
