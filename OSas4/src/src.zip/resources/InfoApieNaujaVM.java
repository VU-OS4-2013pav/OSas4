package resources;

public class InfoApieNaujaVM extends ResourceBase {

}
