package processes;

public class ProcessBase {

}
